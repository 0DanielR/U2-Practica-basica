package com.example.proyectoandroid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
